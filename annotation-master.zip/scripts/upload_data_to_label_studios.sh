#!/bin/bash
# this has to be datalab_adata/images because of nginx
DATA_IMAGE_FOLDER_PATH=/data/gustav/datalab_data/images/*.jpg
PROJECT_ID=10

# Note: you might have to send an initial request to authorize the session, cookie might expire or be different
# Remember to check if you project id is correct. This can be done by checking the url when looking at tasks > http://localhost:8080/projects/1/data?tab=1 => PROJECT_ID=1
# Also test that you can see the image submitted in the "--data-raw"

TOTAL_FILES=$(ls $DATA_IMAGE_FOLDER_PATH | wc -l)

count=0

for filename in $DATA_IMAGE_FOLDER_PATH; do
	FINAL_FILENAME=$(echo "$filename" | rev | cut -d/ -f1 | rev)
	count=$((count + 1))
	echo "Processing file $count/$TOTAL_FILES : $FINAL_FILENAME"	
	curl "http://localhost:8080/api/projects/$PROJECT_ID/import?commit_to_project=true" -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0' -H 'Accept: */*' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H "Referer: http://localhost:8080/projects/$PROJECT_ID/data/import?tab=16" -H 'content-type: application/x-www-form-urlencoded' -H 'Origin: http://localhost:8080' -H 'Connection: keep-alive' -H 'Cookie: csrftoken=O83EGyY3nbTzykSsfKVjhgiLiMDnJBszJeuRWwcFknIhZxIFNzL1BkVn44adObod; _ga=GA1.1.917165088.1631104102; sessionid=.eJxVjDsOwjAQBe-yNYm8ju21Kek5Q-T1OiSAbJRPA-LufERD-2bePGCbBPYQMwVM1jeilW2MTtQEnbBJqKTz6LhTHeygzqdYpntcp1r62wX2uIM-buvYb0ue-28K4W_jmC65fICcYznVNtWyzhO3H6X90aU9VsnXw8_9C4xxGd9vyh6ZTZZhCMYwZlaeaCA7BGEVDGmHVutgRDn22oUUOivkkiFF2jA8X1C1SWI:1mk8PT:qpFIqkkJpiU8tYLksoUUDtQeLu-_kiqtzsrf7M0QCHQ' --data-raw "url=http%3A%2F%2Flocalhost%2F$FINAL_FILENAME"
	echo ""
done
# Copy and replace the "cookie" value 