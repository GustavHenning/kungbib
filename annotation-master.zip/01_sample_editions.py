import pandas as pd
from pandas.core.frame import DataFrame

feather_name="ab-ex-2001-2004"

def skeleton():
    df: DataFrame = pd.read_feather("data/all_metadata.feather")
    df = df[df["created"] >= "1990-01-01"]
    # Keep only one edition when newspaper has multiple editions in same day
    df = df.drop_duplicates(subset=["title", "created"], keep="first")

    most_common_newspapers = (
        df.groupby("title").count().sort_values("dark_id", ascending=False).iloc[0:15,].index.values
    )
    df = df[df["title"].isin(most_common_newspapers)]
    df = df.sample(n=200, random_state=1)

    df = df.reset_index(drop=True)
    df.to_feather("data/sampled_editions.feather")

def gustavsSample():
    df: DataFrame = pd.read_feather("data/all_metadata.feather")
   # df = df[(df["created"] >= "2010-01-01") & (df["created"] < "2021-01-01") & (df["title"] == "DAGENS NYHETER")] # 2010 - 2020, Dagens Nyheter
   # df = df[(df["created"] >= "2001-12-12") & (df["created"] < "2004-06-01") & ((df["title"] == "DAGENS NYHETER") | (df["title"] == "SVENSKA DAGBLADET"))] # 2001-12-12 - 2004-06-01, SvD, Dagens Nyheter
    df = df[(df["created"] >= "2001-12-12") & (df["created"] < "2004-06-01") & ((df["title"] == "AFTONBLADET") | (df["title"] == "EXPRESSEN"))] # 2001-12-12 - 2004-06-01, SvD, Dagens Nyheter

    # Keep only one edition when newspaper has multiple editions in same day
    df = df.drop_duplicates(subset=["title", "created"], keep="first")

    #most_common_newspapers = (
    #    df.groupby("title").count().sort_values("dark_id", ascending=False).iloc[0:15,].index.values
    #)
    #df = df[df["title"].isin(most_common_newspapers)]

    df = df.sample(n=200, random_state=1)

    df = df.reset_index(drop=True)
    df.to_feather("data/{}.feather".format(feather_name))

gustavsSample()
#skeleton()