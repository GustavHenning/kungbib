import os
import multiprocessing

from json import loads

# from time import sleep
import pandas as pd
from tqdm import tqdm
from urllib3.util import Retry
from urllib3 import PoolManager, make_headers
from kblab import Archive
from itertools import product

# Create custom API call to download all metadata files instead of using kblab package
# Retry after failed attempts
def get_metadata(dark_id, headers):
    """Custom API call to download every package's metadata (meta.json) files to filter API content.
    kblab package's .search()-method returns incomplete results, where some some ids are missing
    from search results. Downloading metadata of all id's is the most secure way of ensuring all
    packages are included when filtering for dates or newspaper names.

    Args:
        dark_id (int): URI of package in betalab.kb.se or datalab.kb.se
        headers (list): API authentication details passed as header.

    Returns:
        [dict]: dict with fields of meta.json file.
    """

    http = PoolManager()
    try:
        meta_json = http.request(
            "GET",
            f"https://datalab.kb.se/{dark_id}/meta.json",
            headers=headers,
            retries=Retry(connect=5, read=4, redirect=5, backoff_factor=0.02),
        )

        meta_json = loads(meta_json.data.decode("utf-8"))
        meta_json["dark_id"] = dark_id
        return meta_json

    except:
        return {
            "dark_id": dark_id,
            "title": "failed",
            "created": "failed",
            "year": "failed",
            "edition": "failed",
            "issue": "failed",
        }
        
def download():
    file_input = open("../api_credentials.txt", "r")
    pw = file_input.readlines()
    a = Archive("https://datalab.kb.se/", auth=("demo", pw[0]))
    dark_ids = [dark_id for dark_id in a]  # List of all ids in datalab Archive

    headers = make_headers(basic_auth=f"demo:{pw[0]}")
    pool = multiprocessing.Pool()
    df_meta = pool.starmap(get_metadata, tqdm(list(product(dark_ids, [headers]))), chunksize=5000)
    pool.close()

    os.makedirs("data", exist_ok=True)

    df_meta = pd.DataFrame(df_meta)
    # Keep only newspaper name, throw away date
    df_meta["title"] = df_meta["title"].str.extract(r"(\D*) (\D*)?", expand=False).loc[:, 0]
    df_meta.to_csv("data/all_metadata.csv", index=False)



if __name__ == "__main__":
    #download()
    # Read csv, format columns and remove non newspaper ids. Save as feather.
    df = pd.read_csv("data/all_metadata.csv", low_memory=False)
    df = df[~(df["year"] == "failed")]

    df["year"] = pd.to_numeric(df["year"], errors="coerce")
    df["year"] = df["year"].astype("Int16")
    df["created"] = pd.to_datetime(df["created"], errors="coerce")

    df = df[~df["issue"].isna()]  # Remove ids that aren't newspapers
    df = df.reset_index(drop=True)

    df.to_feather("data/all_metadata.feather", compression=None)
