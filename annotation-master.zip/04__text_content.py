import pandas as pd
import os, glob, sys, json, re
from tqdm import tqdm

def img_name_without_noise(img_name):

    if match := re.search('dark-\d+_part\d+_page\d+(_[^\.]+).jpg', img_name, re.IGNORECASE):
        title = match.group(1)
    if match is None:
        return img_name
    return re.sub(match.group(1), '', img_name)

# we are assuming the df_content feather contains info about images in the image location
#
# !! ANNOTATE RECTS FIRST, THEN DOWNLOAD IMAGES, THEN DOWNLOAD TEXT FOR THOSE IMAGES
#
# TODO: Did you annotate already?
#images_location="data/model/dn-2010-2020" # directory about images AFTER labeling, svd-dn-2001-2004
#df = pd.read_feather("data/df_content.feather") # TODO Content feather for concerned images.

#images_location="data/model/dn-svd-2001-2004" 
#df = pd.read_feather("data/svd-dn-2001-2004-content.feather") 

images_location="data/model/ab-ex-2001-2004" 
df = pd.read_feather("data/ab-ex-2001-2004-content.feather") 

# filename => {stats}
filenames = df["filename"].unique()

images_on_disk = glob.glob(images_location + "/images/*")
img_names = [img.split("/")[-1] for img in images_on_disk]

skipped = 0
no_text = 0

os.makedirs(images_location + "/text", exist_ok=True)

def scaleInt(toScale, scale):
    return int(int(toScale) * scale)

for img in tqdm(img_names):
    name = img_name_without_noise(img)

    if name not in filenames:
        skipped += 1
        continue

    rows = df.loc[(df['filename'] == name) & (df["type"] == "Text")]
    text_contents = {}
    text_contents["name"] = name
    text_contents["filename"] = img
    text_contents["content"] = []

    if len(rows) == 0:
        no_text += 1

    for _, row in rows.iterrows():
        scaleX = row["page_image_width_local"] / row["page_image_width"] 
        scaleY = row["page_image_height_local"] / row["page_image_height"]

        text_contents["content"].append({
            "text": row["content"],
            "x" : scaleInt(row["x"], scaleX),
            "y" : scaleInt(row["y"], scaleY),
            "width" : scaleInt(row["width"], scaleX),
            "height" : scaleInt(row["height"], scaleY)
        })
    with open(images_location + "/text/{}.json".format(os.path.splitext(img)[0]), 'w', encoding='utf8') as f:
        json.dump(text_contents, f, indent=4)

print("Skipped {} images that had no text.".format(no_text))
print("Skipped {} images that could not be found in df_content.feather".format(skipped))
