#!/bin/bash

cd data/ab-ex-2001-2004

find . -type f  -name "*_part03_*" | xargs rm
find . -type f  -name "*_part04_*" | xargs rm
find . -type f  -name "*_part05_*" | xargs rm

cd -